import React from 'react';

const UserIdContext = React.createContext(null);

export default UserIdContext;
